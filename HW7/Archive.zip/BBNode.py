class BBNode(object):
    def __init__(self, parent, dv, bound_sense, bound):

        self.parent = parent
        self.dv = dv
        self.bound_sense = bound_sense
        self.bound = bound
